## How to run

```bash
./netstats -help
Usage of CLI tool:
  -stats: Show network statistics
  -help: Show help information
```

