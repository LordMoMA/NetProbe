## How to run

```bash
./netprobe -help
Usage of CLI tool:
  -stats: Show network statistics
  -help: Show help information
```

